import React, { useState } from 'react';
import { Eye, EyeOff, Loader2 } from 'lucide-react';

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const toggleMode = () => {
    setIsLogin(!isLogin);
    setEmail('');
    setPassword('');
    setShowPassword(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    // Simulate async authentication process
    await new Promise((r) => setTimeout(r, 1500));
    setLoading(false);
    alert(isLogin ? 'Signed in!' : 'Account created!');
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#F8FAFC] p-4">
      <div className="w-full max-w-md space-y-6 rounded-[16px] bg-white p-8 shadow-sm transition-shadow duration-300 hover:shadow-md">
        {/* Logo */}
        <div className="flex justify-center mb-4">
          <svg
            className="h-12 w-12 text-indigo-600"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 4.354a4 4 0 110 7.292M12 12.354a4 4 0 110 7.292M12 20.354a4 4 0 110-7.292"
            />
          </svg>
        </div>
        <h2 className="text-center text-2xl font-bold text-gray-800">
          {isLogin ? 'Welcome Back' : 'Create Your Account'}
        </h2>
        <form onSubmit={handleSubmit} className="mt-4 space-y-5">
          {/* Email */}
          <div className="relative">
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder=" "
              className="peer w-full rounded-md border border-gray-300 bg-gray-50 px-3 py-2.5 text-sm text-gray-900 placeholder-transparent focus:border-indigo-600 focus:outline-none focus:ring-1 focus:ring-indigo-600 transition-all duration-200"
            />
            <label
              htmlFor="email"
              className="absolute left-3 top-2.5 text-sm text-gray-500 transition-all peer-placeholder-shown:top-2.5 peer-placeholder-shown:text-base peer-focus:-top-3 peer-focus:left-3 peer-focus:text-xs peer-focus:text-indigo-600"
            >
              Email address
            </label>
          </div>
          {/* Password */}
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder=" "
              className="peer w-full rounded-md border border-gray-300 bg-gray-50 px-3 py-2.5 pr-10 text-sm text-gray-900 placeholder-transparent focus:border-indigo-600 focus:outline-none focus:ring-1 focus:ring-indigo-600 transition-all duration-200"
            />
            <label
              htmlFor="password"
              className="absolute left-3 top-2.5 text-sm text-gray-500 transition-all peer-placeholder-shown:top-2.5 peer-placeholder-shown:text-base peer-focus:-top-3 peer-focus:left-3 peer-focus:text-xs peer-focus:text-indigo-600"
            >
              Password
            </label>
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute inset-y-0 right-3 flex items-center text-gray-500 hover:text-gray-700"
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          <button
            type="submit"
            disabled={loading}
            className="relative flex w-full items-center justify-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white transition-transform duration-200 hover:scale-105 active:scale-95 disabled:opacity-70"
          >
            {loading && <Loader2 className="absolute left-4 h-4 w-4 animate-spin text-white" />}
            {isLogin ? 'Sign In' : 'Sign Up'}
          </button>
        </form>
        <p className="mt-4 text-center text-sm text-gray-600">
          {isLogin ? "Don\'t have an account? " : "Already have an account? "}
          <button
            type="button"
            onClick={toggleMode}
            className="font-medium text-indigo-600 hover:underline"
          >
            {isLogin ? 'Sign Up' : 'Sign In'}
          </button>
        </p>
      </div>
    </div>
  );
}
