/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        canvas: {
          DEFAULT: '#FDFBF7',
        },
        luxury: {
          gold: '#D4AF37',
          goldLight: '#F5ECE1',
          charcoal: '#2C2A29',
          card: '#FFFFFF',
        }
      },
      boxShadow: {
        luxury: '0 10px 40px rgba(0, 0, 0, 0.02)',
        luxuryHover: '0 20px 50px rgba(212, 175, 55, 0.05)',
      },
      borderRadius: {
        'luxury': '24px',
      },
      fontFamily: {
        luxury: ['Outfit', 'Inter', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
