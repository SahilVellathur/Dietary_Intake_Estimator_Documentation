import Settings from './components/Settings';
import AuthPage from './components/AuthPage';

// ... existing imports above remain

export default function App() {
  const [activePage, setActivePage] = useState('dashboard');

  // High-End Preset Journal Entries (Simulating SQLite retrieved records)
  const [mealHistory, setMealHistory] = useState([
    {
      id: 1,
      date: 'May 19, 2026',
      foodItems: 'Atlantic Salmon with Steamed Broccoli',
      calories: 416,
      macros: { carbs: 13, protein: 43, fat: 73 }
    },
    {
      id: 2,
      date: 'May 18, 2026',
      foodItems: 'Roasted Sweet Potato with Organic Greek Yogurt',
      calories: 231,
      macros: { carbs: 44, protein: 12, fat: 1 }
    }
  ]);

  // Add meal to journal state (Axios POST endpoint hook ready)
  const handleAddMeal = (newMeal) => {
    const mealWithId = {
      ...newMeal,
      id: Date.now()
    };
    setMealHistory(prev => [mealWithId, ...prev]);
  };

  // Delete meal from journal state (Axios DELETE endpoint hook ready)
  const handleDeleteMeal = (id) => {
    setMealHistory(prev => prev.filter(meal => meal.id !== id));
  };

  // Render Active Page with key-based transition triggers
  const renderActivePage = () => {
    switch (activePage) {
      case 'dashboard':
        return <Dashboard onAddMeal={handleAddMeal} />;
      case 'journal':
        return <MealJournal history={mealHistory} onDeleteMeal={handleDeleteMeal} />;
      case 'guide':
        return <FoodGuide onAddMeal={handleAddMeal} />;
      case 'profile':
        return <Profile />;
      case 'settings':
        return <Settings setActivePage={setActivePage} />;
      case 'login':
        return <AuthPage />;
      default:
        return <Dashboard onAddMeal={handleAddMeal} />;
    }
  };

  return (
    <div className="min-h-screen bg-canvas font-sans text-modern-text flex">
      {/* Left Navigation Sidebar */}
      <Sidebar activePage={activePage} setActivePage={setActivePage} />

      {/* Main Workspace Canvas */}
      <main className="flex-1 pl-24 min-h-screen">
        <div className="py-12 px-6 md:px-12 max-w-7xl mx-auto">
          {/* Transition wrapper */}
          <div key={activePage} className="w-full">
            {renderActivePage()}
          </div>
        </div>
        <h2 className="text-center text-2xl font-bold text-gray-800">
          {isLogin ? 'Welcome Back' : 'Create Your Account'}
        </h2>
        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {/* Email */}
          <div className="relative">
            <input
              type="email"
              id="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              className="peer w-full rounded-md border border-gray-300 bg-gray-50 px-3 py-2.5 text-sm text-gray-900 placeholder-transparent focus:border-indigo-600 focus:outline-none focus:ring-1 focus:ring-indigo-600 transition-all duration-200"
              placeholder="Email address"
            />
            <label
              htmlFor="email"
              className="absolute left-3 top-2.5 text-sm text-gray-500 transition-all peer-placeholder-shown:top-2.5 peer-placeholder-shown:text-base peer-focus:-top-3 peer-focus:left-3 peer-focus:text-xs peer-focus:text-indigo-600"
            >
              Email address
            </label>
          </div>
          {/* Password */}
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              id="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
              className="peer w-full rounded-md border border-gray-300 bg-gray-50 px-3 py-2.5 pr-10 text-sm text-gray-900 placeholder-transparent focus:border-indigo-600 focus:outline-none focus:ring-1 focus:ring-indigo-600 transition-all duration-200"
              placeholder="Password"
            />
            <label
              htmlFor="password"
              className="absolute left-3 top-2.5 text-sm text-gray-500 transition-all peer-placeholder-shown:top-2.5 peer-placeholder-shown:text-base peer-focus:-top-3 peer-focus:left-3 peer-focus:text-xs peer-focus:text-indigo-600"
            >
              Password
            </label>
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute inset-y-0 right-3 flex items-center text-gray-500 hover:text-gray-700"
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          <button
            type="submit"
            disabled={loading}
            className="relative flex w-full items-center justify-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white transition-transform duration-200 hover:scale-105 active:scale-95 disabled:opacity-70"
          >
            {loading && (
              <Loader2 className="absolute left-4 h-4 w-4 animate-spin text-white" />
            )}
            {isLogin ? 'Sign In' : 'Sign Up'}
          </button>
        </form>
        <p className="mt-4 text-center text-sm text-gray-600">
          {isLogin ? "Don\'t have an account? " : 'Already have an account? '}
          <button
            type="button"
            onClick={toggleMode}
            className="font-medium text-indigo-600 hover:underline"
          >
            {isLogin ? 'Sign Up' : 'Sign In'}
          </button>
        </p>
      </div>
    </div>
  );
}
