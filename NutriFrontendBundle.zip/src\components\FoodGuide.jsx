import React, { useState } from 'react';
import { Search, Plus, AlertCircle, Check } from 'lucide-react';

export default function FoodGuide({ onAddMeal }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [justAddedId, setJustAddedId] = useState(null);

  // High-End Nutritional Database Mock Data
  const defaultFoods = [
    { id: 1, name: 'Brown Rice', category: 'Grains', calories: 111, carbs: 23, protein: 2.6, fat: 0.9 },
    { id: 2, name: 'Grilled Chicken Breast', category: 'Proteins', calories: 165, carbs: 0, protein: 31, fat: 3.6 },
    { id: 3, name: 'Hass Avocado', category: 'Healthy Fats', calories: 160, carbs: 8.5, protein: 2, fat: 14.7 },
    { id: 4, name: 'Atlantic Salmon', category: 'Proteins', calories: 208, carbs: 0, protein: 20, fat: 13 },
    { id: 5, name: 'Steamed Broccoli', category: 'Vegetables', calories: 34, carbs: 6.6, protein: 2.8, fat: 0.4 },
    { id: 6, name: 'Roasted Sweet Potato', category: 'Grains', calories: 86, carbs: 20, protein: 1.6, fat: 0.1 },
    { id: 7, name: 'Soft Boiled Egg', category: 'Proteins', calories: 155, carbs: 1.1, protein: 13, fat: 11 },
    { id: 8, name: 'Organic Greek Yogurt', category: 'Dairy', calories: 59, carbs: 3.6, protein: 10, fat: 0.4 },
    { id: 9, name: 'Raw Almonds', category: 'Healthy Fats', calories: 579, carbs: 22, protein: 21, fat: 49 },
    { id: 10, name: 'Quinoa', category: 'Grains', calories: 120, carbs: 21, protein: 4.4, fat: 1.9 },
    { id: 11, name: 'Fresh Spinach', category: 'Vegetables', calories: 23, carbs: 3.6, protein: 2.9, fat: 0.4 },
    { id: 12, name: 'Blueberries', category: 'Fruits', calories: 57, carbs: 14, protein: 0.7, fat: 0.3 }
  ];

  // Filtering based on Search Query
  const filteredFoods = defaultFoods.filter(food =>
    food.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    food.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddQuickServing = (food) => {
    onAddMeal({
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      foodItems: `100g serving of ${food.name}`,
      calories: food.calories,
      macros: {
        carbs: food.carbs,
        protein: food.protein,
        fat: food.fat
      }
    });

    // Provide visual positive feedback
    setJustAddedId(food.id);
    setTimeout(() => setJustAddedId(null), 1500);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 animate-fadeIn">
      {/* Page Header */}
      <div className="mb-10">
        <h1 className="text-4xl font-bold tracking-tight text-modern-text">
          Food <span className="text-modern-indigo font-extrabold">Guide</span>
        </h1>
        <p className="text-sm font-medium text-modern-mute mt-2 tracking-wide">
          Quick nutritional reference and catalog indices directly from our dietary database.
        </p>
      </div>

      {/* Highly Polished Search Bar */}
      <div className="relative mb-10 max-w-xl">
        <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-modern-mute/70 stroke-[2.5]" />
        </div>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search foods, categories..."
          className="w-full bg-white text-modern-text pl-12 pr-5 py-4 rounded-2xl shadow-sm border border-modern-border focus:border-modern-indigo focus:ring-2 focus:ring-modern-indigo/10 focus:outline-none transition-all duration-300 ease-out text-sm font-medium placeholder-modern-mute/50"
        />
      </div>

      {/* Grid of Food Blocks */}
      {filteredFoods.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredFoods.map((food, index) => {
            const isAdded = justAddedId === food.id;
            return (
              <div
                key={food.id}
                className="card-modern card-modern-hover p-6 flex flex-col justify-between gap-5 relative overflow-hidden group animate-slideUp border border-modern-border"
                style={{ animationDelay: `${index * 40}ms` }}
              >
                {/* Upper Details */}
                <div>
                  <div className="flex justify-between items-start gap-4">
                    <span className="text-[10px] tracking-wider text-modern-indigo font-bold uppercase bg-modern-indigo-light px-3 py-1 rounded-lg border border-modern-indigo/10">
                      {food.category}
                    </span>
                    <span className="text-xs text-modern-mute/75 font-semibold italic">per 100g</span>
                  </div>
                  <h3 className="text-lg font-bold text-modern-text mt-4 group-hover:text-modern-indigo transition-colors duration-300">
                    {food.name}
                  </h3>
                </div>

                {/* Metrics Section */}
                <div className="grid grid-cols-3 gap-2 bg-slate-50/70 rounded-xl p-3 text-center border border-modern-border">
                  <div className="flex flex-col">
                    <span className="text-[10px] text-modern-mute font-bold tracking-wide">Carbs</span>
                    <span className="text-sm font-extrabold text-modern-text mt-0.5">{food.carbs}g</span>
                  </div>
                  <div className="flex flex-col border-l border-r border-modern-border">
                    <span className="text-[10px] text-modern-mute font-bold tracking-wide">Protein</span>
                    <span className="text-sm font-extrabold text-modern-text mt-0.5">{food.protein}g</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[10px] text-modern-mute font-bold tracking-wide">Fat</span>
                    <span className="text-sm font-extrabold text-modern-text mt-0.5">{food.fat}g</span>
                  </div>
                </div>

                {/* Footer block: Calories & Add Servings Button */}
                <div className="flex justify-between items-center pt-3 border-t border-modern-border">
                  <div className="flex flex-col">
                    <span className="text-[9px] tracking-wider text-modern-mute font-bold uppercase">Energy</span>
                    <div className="flex items-baseline gap-0.5">
                      <span className="text-lg font-extrabold text-modern-indigo">{food.calories}</span>
                      <span className="text-[10px] text-modern-mute font-semibold">kcal</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleAddQuickServing(food)}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold tracking-wide transition-all duration-200 focus:outline-none shadow-sm cursor-pointer active:scale-95 btn-hover-effect border ${
                      isAdded
                        ? 'bg-modern-emerald-light text-modern-emerald border-modern-emerald/20'
                        : 'bg-modern-indigo text-white hover:bg-modern-indigo-hover border-modern-indigo'
                    }`}
                  >
                    {isAdded ? (
                      <>
                        <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                        <span>Logged</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-3.5 h-3.5 text-white" />
                        <span>Log 100g</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        // Minimalist Search Empty State
        <div className="card-modern p-12 flex flex-col items-center text-center gap-4 py-16 animate-fadeIn border border-modern-border">
          <div className="w-12 h-12 rounded-full bg-modern-rose-light flex items-center justify-center border border-modern-rose/10 text-modern-rose mb-2">
            <AlertCircle className="w-5 h-5 stroke-[2.5]" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-modern-text">No Foods Found</h3>
            <p className="text-modern-mute text-sm font-medium tracking-wide max-w-sm mt-2 leading-relaxed">
              No matching items found for "{searchQuery}". Try searching for grains, proteins, or healthy fats.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
