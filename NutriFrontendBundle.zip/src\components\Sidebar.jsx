import React from 'react';
import { Home, BookOpen, Search, Sparkles, User } from 'lucide-react';

export default function Sidebar({ activePage, setActivePage }) {
  const navItems = [
    { id: 'dashboard', icon: Home, label: 'Dashboard' },
    { id: 'journal', icon: BookOpen, label: 'Meal Journal' },
    { id: 'guide', icon: Search, label: 'Food Guide' },
    { id: 'profile', icon: User, label: 'Profile' }
  ];

  return (
    <aside className="fixed top-0 left-0 h-screen w-24 bg-white/90 backdrop-blur-md flex flex-col items-center justify-between py-10 shadow-sm rounded-r-3xl z-50 transition-all duration-300 ease-out border-r border-modern-border">
      {/* Brand Elegant Monogram */}
      <div className="flex flex-col items-center gap-1 group cursor-pointer">
        <div className="w-10 h-10 rounded-full bg-modern-indigo-light flex items-center justify-center border border-modern-indigo/15 group-hover:scale-105 group-hover:border-modern-indigo/40 transition-all duration-300 shadow-sm">
          <Sparkles className="w-5 h-5 text-modern-indigo animate-pulse" />
        </div>
        <span className="text-[10px] tracking-[0.2em] font-sans text-modern-indigo mt-1.5 font-bold">DIET</span>
      </div>

      {/* Navigation Icons */}
      <nav className="flex flex-col gap-8 my-auto relative">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activePage === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActivePage(item.id)}
              className="relative group p-4 flex items-center justify-center focus:outline-none transition-transform duration-150 active:scale-90"
              aria-label={item.label}
            >
              {/* Soft Active Indigo and Icon Styling */}
              <div
                className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-300 ease-out ${
                  isActive
                    ? 'bg-modern-indigo text-white shadow-md shadow-modern-indigo/20 border border-modern-indigo'
                    : 'text-modern-mute hover:text-modern-text hover:bg-slate-100 border border-transparent'
                }`}
              >
                <Icon className="w-5 h-5 stroke-[1.5]" />
              </div>

              {/* Tooltip */}
              <span className="absolute left-20 bg-modern-text text-white text-[10px] font-sans tracking-wider py-1.5 px-3 rounded-lg opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap shadow-md border border-slate-700">
                {item.label}
              </span>

              {/* Delicate Indigo Accent Bar */}
              {isActive && (
                <div className="absolute left-0 w-[4px] h-8 bg-modern-indigo rounded-r-full transition-all duration-300 ease-out shadow-[0_0_8px_rgba(79,70,229,0.4)]" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer / Credit Monogram */}
      <div className="flex flex-col items-center">
        <div className="w-[2px] h-8 bg-modern-border rounded-full" />
        <span className="text-[9px] tracking-wider text-modern-mute/60 font-medium mt-3 font-sans">v1.0</span>
      </div>
    </aside>
  );
}

