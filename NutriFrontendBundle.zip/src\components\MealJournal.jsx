import React from 'react';
import { Calendar, Trash2, BookOpen } from 'lucide-react';

export default function MealJournal({ history, onDeleteMeal }) {
  
  return (
    <div className="max-w-4xl mx-auto px-4 py-8 animate-fadeIn">
      {/* Page Header */}
      <div className="mb-10 flex flex-col sm:flex-row sm:justify-between sm:items-end gap-4">
        <div>
          <h1 className="text-4xl font-bold tracking-tight text-modern-text">
            Meal <span className="text-modern-indigo font-extrabold">Journal</span>
          </h1>
          <p className="text-sm font-medium text-modern-mute mt-2 tracking-wide">
            Your chronicled history of culinary balance and nutritional mindfulness.
          </p>
        </div>
        <div className="card-modern px-5 py-2.5 rounded-xl flex items-center gap-2 border border-modern-border shadow-sm bg-white self-start sm:self-auto">
          <Calendar className="w-4 h-4 text-modern-indigo" />
          <span className="text-xs font-bold text-modern-text tracking-wide">
            {history.length} {history.length === 1 ? 'Entry' : 'Entries'}
          </span>
        </div>
      </div>

      {/* Timeline Layout */}
      {history.length > 0 ? (
        <div className="relative pl-8 border-l-2 border-modern-border flex flex-col gap-6">
          {history.map((meal, index) => (
            <div key={meal.id || index} className="relative group animate-slideUp" style={{ animationDelay: `${index * 80}ms` }}>
              {/* Timeline Indigo Pearl dot */}
              <div className="absolute -left-[39px] top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-white border-2 border-modern-indigo flex items-center justify-center shadow-sm z-10 transition-transform duration-300 group-hover:scale-125">
                <div className="w-1.5 h-1.5 rounded-full bg-modern-indigo" />
              </div>

              {/* Horizontal Capsule Card */}
              <div className="card-modern card-modern-hover p-5 pl-8 pr-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border border-modern-border">
                {/* Left: Date and Food details */}
                <div className="flex flex-col gap-1.5 max-w-lg">
                  <span className="text-[10px] tracking-wider text-modern-indigo font-bold uppercase bg-modern-indigo-light px-2.5 py-0.5 rounded-md self-start">
                    {meal.date}
                  </span>
                  <h4 className="text-xl font-bold text-modern-text leading-snug group-hover:text-modern-indigo transition-colors duration-300">
                    {meal.foodItems}
                  </h4>
                  {meal.macros && (
                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs font-semibold text-modern-mute mt-1 tracking-wide">
                      <span>Carbs: <strong className="text-modern-text font-bold">{meal.macros.carbs}g</strong></span>
                      <span className="text-slate-300">•</span>
                      <span>Protein: <strong className="text-modern-text font-bold">{meal.macros.protein}g</strong></span>
                      <span className="text-slate-300">•</span>
                      <span>Fats: <strong className="text-modern-text font-bold">{meal.macros.fat}g</strong></span>
                    </div>
                  )}
                </div>

                {/* Right: Calories summary & Delete action */}
                <div className="flex items-center gap-6 self-stretch md:self-auto justify-between md:justify-end border-t md:border-t-0 border-modern-border pt-4 md:pt-0">
                  <div className="flex flex-col items-end">
                    <span className="text-[9px] tracking-wider text-modern-mute font-bold uppercase">Energy</span>
                    <div className="flex items-baseline gap-1 mt-0.5">
                      <span className="text-2xl font-extrabold text-modern-indigo">{meal.calories}</span>
                      <span className="text-xs text-modern-mute font-bold">kcal</span>
                    </div>
                  </div>

                  <button
                    onClick={() => onDeleteMeal(meal.id || index)}
                    className="p-2.5 rounded-xl text-modern-mute hover:text-modern-rose hover:bg-modern-rose-light border border-transparent hover:border-modern-rose/20 transition-all duration-200 focus:outline-none cursor-pointer active:scale-90"
                    title="Remove Entry"
                  >
                    <Trash2 className="w-4 h-4 stroke-[2]" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        // Modern Empty State
        <div className="card-modern p-12 flex flex-col items-center text-center gap-4 py-16 animate-fadeIn border border-modern-border">
          <div className="w-16 h-16 rounded-full bg-modern-indigo-light flex items-center justify-center border border-modern-indigo/10 mb-2">
            <BookOpen className="w-6 h-6 text-modern-indigo stroke-[2]" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-modern-text">Journal is Empty</h3>
            <p className="text-modern-mute text-sm font-semibold tracking-wide max-w-sm mt-2 leading-relaxed">
              No historical meal estimates are cataloged yet. Navigate back to the Dashboard to analyze and save your first plate!
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
