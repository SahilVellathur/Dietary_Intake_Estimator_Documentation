import React, { useState, useEffect, useRef } from 'react';
import { User, Target, Award, Settings, Camera, Check, Plus, Loader2, Smartphone, ShieldCheck, HelpCircle } from 'lucide-react';
import avatarImg from '../assets/user_avatar.png';

export default function Profile() {
  // Avatar local upload state
  const [avatarSrc, setAvatarSrc] = useState(avatarImg);
  const avatarInputRef = useRef(null);
  // State for user details
  const [user, setUser] = useState({
    name: 'Alexander Mercer',
    email: 'alex.mercer@nutriflow.io',
    targetCalories: 2200,
    macros: {
      carbs: 220, // 40%
      protein: 165, // 30%
      fat: 73 // 30%
    }
  });

  // Edit State
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(user.name);
  const [editEmail, setEditEmail] = useState(user.email);
  const [editCalories, setEditCalories] = useState(user.targetCalories);

  // Animation Trigger State
  const [isMounted, setIsMounted] = useState(false);

  // Water tracker state
  const [waterCups, setWaterCups] = useState(4);
  const targetWaterCups = 8;

  // Syncing states
  const [devices, setDevices] = useState([
    { id: 'apple', name: 'Apple Health', connected: true, icon: Smartphone },
    { id: 'garmin', name: 'Garmin Connect', connected: false, icon: Settings },
    { id: 'fitbit', name: 'Fitbit Sync', connected: false, icon: Settings }
  ]);
  
  const [syncingId, setSyncingId] = useState(null);

  useEffect(() => {
    // Trigger progress animations on mount
    const timer = setTimeout(() => setIsMounted(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const handleSaveProfile = (e) => {
    e.preventDefault();
    setUser(prev => ({
      ...prev,
      name: editName,
      email: editEmail,
      targetCalories: Number(editCalories),
      macros: {
        carbs: Math.round(Number(editCalories) * 0.4 / 4),
        protein: Math.round(Number(editCalories) * 0.3 / 4),
        fat: Math.round(Number(editCalories) * 0.3 / 9)
      }
    }));
    setIsEditing(false);
  };

  const toggleDevice = (id) => {
    setSyncingId(id);
    setTimeout(() => {
      setDevices(prev => prev.map(d => d.id === id ? { ...d, connected: !d.connected } : d));
      setSyncingId(null);
    }, 1200);
  };

  const handleAvatarChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setAvatarSrc(URL.createObjectURL(file));
    }
  };

  const handleAvatarClick = () => {
    if (avatarInputRef.current) {
      avatarInputRef.current.click();
    }
  };

  // Macro Calculation helper
  const carbPct = 40;
  const proteinPct = 30;
  const fatPct = 30;

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 animate-fadeIn">
      {/* Modern Greeting Header */}
      <div className="mb-10 flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold tracking-tight text-modern-text">
            Profile & <span className="text-modern-indigo font-extrabold">Settings</span>
          </h1>
          <p className="text-sm font-medium text-modern-mute mt-2 tracking-wide">
            Manage your biological goals, connected biosensors, and macro metrics.
          </p>
        </div>
        <div className="w-10 h-10 rounded-xl bg-white border border-modern-border flex items-center justify-center text-modern-mute hover:text-modern-indigo transition-colors duration-250 cursor-pointer shadow-sm">
          <Settings className="w-5 h-5" />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Left Column (Span 5): User Overview & Goals */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          
          {/* User Overview Card */}
          <div className="card-modern p-6 flex flex-col gap-6 hover:translate-y-[-3px] hover:shadow-lg hover:shadow-modern-indigo/5 transition-all duration-300 ease-out">
            {/* Hidden Input for Local Disk Avatar Upload */}
            <input
              type="file"
              id="avatar-upload"
              ref={avatarInputRef}
              onChange={handleAvatarChange}
              accept="image/*"
              className="hidden"
            />
            <div className="flex items-center gap-5">
              {/* Profile Image with Hover Overlay */}
              <div 
                onClick={handleAvatarClick}
                className="relative w-20 h-20 rounded-2xl overflow-hidden border border-modern-border cursor-pointer group shadow-sm bg-slate-50 flex-shrink-0"
              >
                <img 
                  src={avatarSrc} 
                  alt="Profile Avatar" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                />
                <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 group-hover:scale-105 transition-all duration-300 flex flex-col items-center justify-center text-white gap-1 z-10">
                  <Camera className="w-4 h-4" />
                  <span className="text-[8px] font-bold tracking-wider uppercase font-sans">Change Photo</span>
                </div>
              </div>

              <div>
                <h2 className="text-xl font-bold text-modern-text">{user.name}</h2>
                <p className="text-xs text-modern-mute font-medium mt-0.5">{user.email}</p>
                <span className="inline-flex items-center gap-1.5 mt-2 bg-modern-indigo-light text-modern-indigo text-[10px] font-bold px-2.5 py-1 rounded-md">
                  <ShieldCheck className="w-3.5 h-3.5" /> Premium Member
                </span>
              </div>
            </div>

            {/* Edit Button */}
            {!isEditing && (
              <button
                onClick={() => setIsEditing(true)}
                className="w-full bg-slate-50 hover:bg-modern-indigo-light text-modern-text hover:text-modern-indigo border border-modern-border hover:border-modern-indigo/15 py-2.5 rounded-xl text-xs font-bold transition-all duration-200 tracking-wider uppercase shadow-sm active:scale-95 btn-hover-effect"
              >
                Edit Profile
              </button>
            )}

            {/* Smooth Slide-out Edit Fields */}
            <div className={`transition-all duration-500 ease-in-out overflow-hidden ${
              isEditing ? 'max-h-[350px] opacity-100 border-t border-modern-border pt-4' : 'max-h-0 opacity-0 pointer-events-none'
            }`}>
              <form onSubmit={handleSaveProfile} className="flex flex-col gap-4">
                <div>
                  <label className="text-[10px] font-bold text-modern-text uppercase tracking-wider block mb-1.5">Full Name</label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    required
                    className="w-full text-xs font-medium border border-modern-border rounded-xl px-3.5 py-2.5 bg-slate-50/50 focus:bg-white focus:border-modern-indigo focus:ring-1 focus:ring-modern-indigo/25 outline-none transition-all duration-200"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-modern-text uppercase tracking-wider block mb-1.5">Email Address</label>
                  <input
                    type="email"
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                    required
                    className="w-full text-xs font-medium border border-modern-border rounded-xl px-3.5 py-2.5 bg-slate-50/50 focus:bg-white focus:border-modern-indigo focus:ring-1 focus:ring-modern-indigo/25 outline-none transition-all duration-200"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-modern-text uppercase tracking-wider block mb-1.5">Daily Calorie Target</label>
                  <input
                    type="number"
                    value={editCalories}
                    onChange={(e) => setEditCalories(e.target.value)}
                    required
                    min="1000"
                    max="10000"
                    className="w-full text-xs font-medium border border-modern-border rounded-xl px-3.5 py-2.5 bg-slate-50/50 focus:bg-white focus:border-modern-indigo focus:ring-1 focus:ring-modern-indigo/25 outline-none transition-all duration-200"
                  />
                </div>
                <div className="flex gap-3 mt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsEditing(false);
                      setEditName(user.name);
                      setEditEmail(user.email);
                      setEditCalories(user.targetCalories);
                    }}
                    className="w-1/2 bg-slate-50 text-modern-mute hover:bg-slate-100 py-2.5 rounded-xl text-xs font-bold border border-modern-border transition-all duration-200 active:scale-95"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="w-1/2 bg-modern-indigo hover:bg-modern-indigo-hover text-white py-2.5 rounded-xl text-xs font-bold transition-all duration-200 shadow-md shadow-modern-indigo/10 active:scale-95 flex items-center justify-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" /> Save Changes
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Dietary Goals Card */}
          <div className="card-modern p-6 flex flex-col gap-6 hover:translate-y-[-3px] hover:shadow-lg hover:shadow-modern-indigo/5 transition-all duration-300 ease-out">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-modern-indigo-light flex items-center justify-center border border-modern-indigo/10">
                <Target className="w-5 h-5 text-modern-indigo" />
              </div>
              <div>
                <h3 className="text-md font-bold text-modern-text">Dietary Goals</h3>
                <p className="text-[10px] text-modern-mute font-medium tracking-wide">Target calories and macronutrient breakdown</p>
              </div>
            </div>

            {/* Target Calories progress bar */}
            <div className="border-t border-modern-border pt-4">
              <div className="flex justify-between items-baseline mb-2">
                <span className="text-xs font-bold text-modern-text">Target Calories</span>
                <span className="text-sm font-extrabold text-modern-indigo">{user.targetCalories} <span className="text-[10px] font-normal text-modern-mute">kcal/day</span></span>
              </div>
              <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden border border-modern-border">
                <div 
                  className="h-full bg-modern-indigo rounded-full transition-all duration-1000 ease-out" 
                  style={{ width: isMounted ? '100%' : '0%' }}
                />
              </div>
            </div>

            {/* Macros progress bars */}
            <div className="flex flex-col gap-4 border-t border-modern-border pt-4">
              <h4 className="text-[10px] font-bold text-modern-text uppercase tracking-wider">Macronutrients Split</h4>
              
              {/* Carbs */}
              <div>
                <div className="flex justify-between text-xs mb-1.5 font-semibold">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-modern-indigo" />
                    <span className="text-modern-mute font-bold">Carbohydrates</span>
                  </div>
                  <span className="text-modern-text">{user.macros.carbs}g ({carbPct}%)</span>
                </div>
                <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-modern-indigo rounded-full transition-all duration-1000 ease-out" 
                    style={{ width: isMounted ? `${carbPct}%` : '0%' }}
                  />
                </div>
              </div>

              {/* Protein */}
              <div>
                <div className="flex justify-between text-xs mb-1.5 font-semibold">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-modern-emerald" />
                    <span className="text-modern-mute font-bold">Protein</span>
                  </div>
                  <span className="text-modern-text">{user.macros.protein}g ({proteinPct}%)</span>
                </div>
                <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-modern-emerald rounded-full transition-all duration-1000 ease-out" 
                    style={{ width: isMounted ? `${proteinPct}%` : '0%' }}
                  />
                </div>
              </div>

              {/* Fat */}
              <div>
                <div className="flex justify-between text-xs mb-1.5 font-semibold">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-amber-500" />
                    <span className="text-modern-mute font-bold">Fats</span>
                  </div>
                  <span className="text-modern-text">{user.macros.fat}g ({fatPct}%)</span>
                </div>
                <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-amber-500 rounded-full transition-all duration-1000 ease-out" 
                    style={{ width: isMounted ? `${fatPct}%` : '0%' }}
                  />
                </div>
              </div>
            </div>

            {/* Water Tracker */}
            <div className="border-t border-modern-border pt-4 flex flex-col gap-3">
              <div className="flex justify-between items-baseline">
                <span className="text-xs font-bold text-modern-text">Water Intake Tracker</span>
                <span className="text-sm font-extrabold text-modern-indigo">{waterCups} / {targetWaterCups} <span className="text-[10px] font-normal text-modern-mute">cups</span></span>
              </div>
              
              {/* Cup indicators grid */}
              <div className="flex gap-2 justify-between">
                {Array.from({ length: targetWaterCups }).map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setWaterCups(Math.max(i + 1, waterCups === i + 1 ? i : i + 1))}
                    className={`w-7 h-8 rounded-lg flex items-center justify-center transition-all duration-300 focus:outline-none border active:scale-90 ${
                      i < waterCups 
                        ? 'bg-modern-indigo/10 border-modern-indigo text-modern-indigo scale-105' 
                        : 'bg-slate-50 border-modern-border text-modern-mute hover:bg-slate-100'
                    }`}
                  >
                    🥛
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (Span 7): Nutritional Progress & Connected Devices */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          
          {/* Nutritional Progress overview */}
          <div className="card-modern p-6 flex flex-col gap-6 hover:translate-y-[-3px] hover:shadow-lg hover:shadow-modern-indigo/5 transition-all duration-300 ease-out">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-modern-indigo-light flex items-center justify-center border border-modern-indigo/10">
                <Award className="w-5 h-5 text-modern-indigo" />
              </div>
              <div>
                <h3 className="text-md font-bold text-modern-text">Nutritional Progress</h3>
                <p className="text-[10px] text-modern-mute font-medium tracking-wide">Historical logs and calorie fidelity metrics</p>
              </div>
            </div>

            {/* Dynamic summary grid */}
            <div className="grid grid-cols-3 gap-4 border-t border-modern-border pt-4">
              <div className="bg-slate-50/50 border border-modern-border rounded-2xl p-4 flex flex-col items-center justify-center text-center shadow-sm">
                <span className="text-[9px] tracking-wider text-modern-mute font-bold uppercase mb-1">Days Tracked</span>
                <span className="text-2xl font-extrabold text-modern-indigo">24</span>
                <span className="text-[9px] text-modern-mute font-medium mt-0.5">Consecutive</span>
              </div>

              <div className="bg-slate-50/50 border border-modern-border rounded-2xl p-4 flex flex-col items-center justify-center text-center shadow-sm">
                <span className="text-[9px] tracking-wider text-modern-mute font-bold uppercase mb-1">Avg Calories</span>
                <span className="text-2xl font-extrabold text-modern-indigo">1,940</span>
                <span className="text-[9px] text-modern-mute font-medium mt-0.5">kcal / daily</span>
              </div>

              <div className="bg-slate-50/50 border border-modern-border rounded-2xl p-4 flex flex-col items-center justify-center text-center shadow-sm">
                <span className="text-[9px] tracking-wider text-modern-mute font-bold uppercase mb-1">Meal Accuracy</span>
                <span className="text-2xl font-extrabold text-modern-emerald">92%</span>
                <span className="text-[9px] text-modern-mute font-medium mt-0.5">AI Fidelity</span>
              </div>
            </div>

            {/* Streak card banner */}
            <div className="bg-gradient-to-r from-modern-indigo to-indigo-600 rounded-2xl p-5 text-white flex justify-between items-center relative overflow-hidden shadow-md">
              <div className="absolute right-0 bottom-0 translate-x-4 translate-y-4 opacity-10">
                <Award className="w-40 h-40" />
              </div>
              <div className="relative z-10">
                <h4 className="font-bold text-sm">Amazing Track Record!</h4>
                <p className="text-[11px] text-indigo-100 mt-1 max-w-sm">
                  You've maintained your nutritional balance streak for 12 days straight. Keep uploading your meals to secure the monthly badge!
                </p>
              </div>
              <div className="relative z-10 w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center font-extrabold text-lg shadow-inner">
                🔥
              </div>
            </div>
          </div>

          {/* Connected Biosensors & Devices */}
          <div className="card-modern p-6 flex flex-col gap-6 hover:translate-y-[-3px] hover:shadow-lg hover:shadow-modern-indigo/5 transition-all duration-300 ease-out">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-modern-indigo-light flex items-center justify-center border border-modern-indigo/10">
                <Smartphone className="w-5 h-5 text-modern-indigo" />
              </div>
              <div>
                <h3 className="text-md font-bold text-modern-text">Connected Devices</h3>
                <p className="text-[10px] text-modern-mute font-medium tracking-wide">Sync automatic biological metrics from external wearables</p>
              </div>
            </div>

            {/* Device list */}
            <div className="flex flex-col gap-4 border-t border-modern-border pt-4">
              {devices.map((device) => {
                const Icon = device.icon;
                const isSyncing = syncingId === device.id;
                
                return (
                  <div key={device.id} className="flex justify-between items-center p-4 rounded-2xl border border-modern-border bg-slate-50/50 hover:bg-white transition-all duration-200">
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center border ${
                        device.connected 
                          ? 'bg-modern-indigo-light border-modern-indigo/15 text-modern-indigo' 
                          : 'bg-slate-100 border-modern-border text-modern-mute'
                      }`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-modern-text">{device.name}</h4>
                        <p className="text-[9px] text-modern-mute font-medium">
                          {device.connected ? 'Auto-syncing active' : 'Disconnected'}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => toggleDevice(device.id)}
                      disabled={isSyncing}
                      className={`px-4 py-1.5 rounded-xl text-[10px] font-bold tracking-wider uppercase transition-all duration-200 active:scale-95 flex items-center gap-1.5 cursor-pointer border ${
                        isSyncing
                          ? 'bg-white border-modern-border text-modern-mute'
                          : device.connected
                            ? 'bg-white border-modern-border hover:border-modern-rose/20 text-modern-mute hover:text-modern-rose hover:bg-modern-rose-light'
                            : 'bg-modern-indigo hover:bg-modern-indigo-hover text-white border-transparent shadow-sm'
                      }`}
                    >
                      {isSyncing ? (
                        <>
                          <Loader2 className="w-3 h-3 animate-spin text-modern-indigo" />
                          Syncing
                        </>
                      ) : device.connected ? (
                        'Disconnect'
                      ) : (
                        <>
                          <Plus className="w-3 h-3" />
                          Connect
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
            
            {/* Wearable Info Box */}
            <div className="bg-slate-50 rounded-2xl p-4 flex gap-3 items-start border border-modern-border">
              <HelpCircle className="w-5 h-5 text-modern-mute mt-0.5 flex-shrink-0" />
              <div className="flex-1">
                <h5 className="text-xs font-bold text-modern-text">Why sync wearables?</h5>
                <p className="text-[10px] text-modern-mute leading-relaxed mt-1 font-medium">
                  Connecting Apple Health, Garmin, or Fitbit enables NutriFlow to automatically read active energy expenditure, recalculate target calorie targets in real-time, and refine macronutrient calculations.
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
