import React, { useState, useRef, useEffect } from 'react';
import { Upload, Camera, Sparkles, Plus, Check, Loader2, ArrowRight, X, Trash2, ShieldAlert } from 'lucide-react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Doughnut } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend);

export default function Dashboard({ onAddMeal }) {
  const [selectedImage, setSelectedImage] = useState(null);
  const [dragActive, setDragActive] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  
  // Camera States
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [streamActive, setStreamActive] = useState(false);
  const [cameraError, setCameraError] = useState(null);
  const [showFlash, setShowFlash] = useState(false);
  
  const fileInputRef = useRef(null);
  const videoRef = useRef(null);
  const streamRef = useRef(null);

  // Cleanup camera stream on unmount
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  // Handle Drag Events
  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  // Handle Drop Event
  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setSelectedImage(URL.createObjectURL(file));
      setAnalysisResult(null);
    }
  };

  // Handle File Input Selection
  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedImage(URL.createObjectURL(file));
      setAnalysisResult(null);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current.click();
  };

  // Camera Open Logic
  const handleOpenCamera = async () => {
    setIsCameraOpen(true);
    setCameraError(null);
    setStreamActive(false);

    try {
      const constraints = {
        video: {
          facingMode: 'environment',
          width: { ideal: 1024 },
          height: { ideal: 1024 }
        },
        audio: false
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      
      // Delay slightly to let the modal mount and the video ref assign
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setStreamActive(true);
        }
      }, 150);
    } catch (err) {
      console.error("Camera access error:", err);
      // Fallback to basic user-facing video constraints
      try {
        const fallbackStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
        streamRef.current = fallbackStream;
        setTimeout(() => {
          if (videoRef.current) {
            videoRef.current.srcObject = fallbackStream;
            setStreamActive(true);
          }
        }, 150);
      } catch (fallbackErr) {
        setCameraError("Camera access denied or unavailable. Please enable device permissions.");
      }
    }
  };

  // Camera Close Logic
  const handleCloseCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraOpen(false);
    setStreamActive(false);
    setCameraError(null);
  };

  // Canvas snapping logic
  const handleCapturePhoto = () => {
    if (!videoRef.current) return;

    // Trigger flash animation
    setShowFlash(true);
    setTimeout(() => {
      setShowFlash(false);
    }, 150);

    const video = videoRef.current;
    
    // Create an offscreen canvas
    const canvas = document.createElement('canvas');
    const size = Math.min(video.videoWidth, video.videoHeight);
    canvas.width = size;
    canvas.height = size;
    
    const ctx = canvas.getContext('2d');
    
    // Mirror standard user webcam layout
    ctx.translate(canvas.width, 0);
    ctx.scale(-1, 1);
    
    const sx = (video.videoWidth - size) / 2;
    const sy = (video.videoHeight - size) / 2;
    ctx.drawImage(video, sx, sy, size, size, 0, 0, size, size);
    
    const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
    setSelectedImage(dataUrl);
    setAnalysisResult(null);

    // Stop streams and close modal
    setTimeout(() => {
      handleCloseCamera();
    }, 200);
  };

  // Simulated AI Dietary Analysis
  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    
    // Simulate premium AI processing delay
    setTimeout(() => {
      const mockResult = {
        mealName: "Avocado Sourdough Toast with Poached Egg",
        calories: 385,
        macros: {
          carbs: { value: 42, percentage: 45, label: "Carbohydrates", color: "#6366F1" }, // Modern Indigo
          protein: { value: 16, percentage: 20, label: "Protein", color: "#10B981" },      // Emerald Green
          fat: { value: 17, percentage: 35, label: "Fats", color: "#F59E0B" }            // Vibrant Amber
        },
        ingredients: ["Sourdough Bread (80g)", "Avocado (100g)", "Poached Egg (50g)", "Microgreens & Olive Oil"],
        saved: false
      };
      
      setAnalysisResult(mockResult);
      setIsAnalyzing(false);
    }, 2000);
  };

  const handleSaveToHistory = () => {
    if (!analysisResult) return;
    
    onAddMeal({
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      foodItems: analysisResult.mealName,
      calories: analysisResult.calories,
      macros: {
        carbs: analysisResult.macros.carbs.value,
        protein: analysisResult.macros.protein.value,
        fat: analysisResult.macros.fat.value
      }
    });

    setAnalysisResult(prev => ({ ...prev, saved: true }));
  };

  // ChartJS Data Configuration
  const chartData = analysisResult ? {
    labels: ['Carbs', 'Protein', 'Fats'],
    datasets: [{
      data: [
        analysisResult.macros.carbs.percentage,
        analysisResult.macros.protein.percentage,
        analysisResult.macros.fat.percentage
      ],
      backgroundColor: [
        analysisResult.macros.carbs.color,
        analysisResult.macros.protein.color,
        analysisResult.macros.fat.color
      ],
      borderWidth: 0,
      hoverOffset: 6
    }]
  } : null;

  const chartOptions = {
    cutout: '80%',
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            return ` ${context.label}: ${context.raw}%`;
          }
        },
        backgroundColor: '#0F172A',
        titleFont: { family: 'Outfit', size: 12 },
        bodyFont: { family: 'Inter', size: 12 },
        padding: 12,
        cornerRadius: 12,
        displayColors: false
      }
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 animate-fadeIn">
      {/* Modern Greeting Header */}
      <div className="mb-10">
        <h1 className="text-4xl font-bold tracking-tight text-modern-text">
          Your <span className="text-modern-indigo font-extrabold">Plate</span> Today
        </h1>
        <p className="text-sm font-medium text-modern-mute mt-2 tracking-wide">
          Estimate calories and macronutrients instantly with computer vision intelligence.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
        {/* Left: Upload and Preview Widget */}
        <div className="flex flex-col gap-6">
          <div
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            className={`card-modern p-8 flex flex-col items-center justify-center min-h-[380px] relative overflow-hidden transition-all duration-300 ${
              dragActive 
                ? 'border-modern-indigo bg-modern-indigo-light/50 scale-[1.01] shadow-lg shadow-modern-indigo/10' 
                : 'border-modern-border hover:border-modern-indigo/20'
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />

            {/* Container for smooth state transitions */}
            <div className="w-full relative flex flex-col items-center justify-center">
              
              {/* Empty State Upload UI (Dual options) */}
              <div className={`w-full flex flex-col items-center text-center gap-6 py-6 transition-all duration-500 ease-in-out ${
                selectedImage 
                  ? 'opacity-0 scale-90 pointer-events-none absolute' 
                  : 'opacity-100 scale-100'
              }`}>
                <div className="w-16 h-16 rounded-full bg-modern-indigo-light flex items-center justify-center border border-modern-indigo/10 shadow-sm transition-transform duration-300">
                  <Camera className="w-6 h-6 text-modern-indigo stroke-[2]" />
                </div>
                <div>
                  <p className="text-modern-text font-bold text-lg">Add a Photo of Your Meal</p>
                  <p className="text-modern-mute text-xs mt-1.5 font-medium tracking-wide max-w-xs leading-relaxed">
                    Select a method to capture or upload your dish for immediate AI nutrition insights.
                  </p>
                </div>
                
                <div className="grid grid-cols-2 gap-4 w-full max-w-sm mt-2">
                  {/* Browse files option */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      triggerFileInput();
                    }}
                    className="flex flex-col items-center justify-center p-4 rounded-2xl border border-modern-border bg-slate-50/60 hover:bg-modern-indigo/[0.03] hover:translate-y-[-4px] hover:border-modern-indigo/50 hover:shadow-lg hover:shadow-modern-indigo/5 transition-all duration-300 ease-out cursor-pointer active:scale-95 group"
                  >
                    <Upload className="w-5 h-5 text-modern-mute group-hover:text-modern-indigo transition-colors duration-250 mb-2 stroke-[2] animate-bounce-subtle" />
                    <span className="text-xs font-bold text-modern-text">Browse Files</span>
                    <span className="text-[10px] text-modern-mute mt-1 font-medium">Local Picker</span>
                  </button>

                  {/* Take photo option */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleOpenCamera();
                    }}
                    className="flex flex-col items-center justify-center p-4 rounded-2xl border border-modern-border bg-slate-50/60 hover:bg-modern-indigo/[0.03] hover:translate-y-[-4px] hover:border-modern-indigo/50 hover:shadow-lg hover:shadow-modern-indigo/5 transition-all duration-300 ease-out cursor-pointer active:scale-95 group"
                  >
                    <Camera className="w-5 h-5 text-modern-mute group-hover:text-modern-indigo transition-colors duration-250 mb-2 stroke-[2] animate-camera-rotate" />
                    <span className="text-xs font-bold text-modern-text">Take a Photo</span>
                    <span className="text-[10px] text-modern-mute mt-1 font-medium">Use Camera</span>
                  </button>
                </div>
              </div>

              {/* Clipped Image Preview Box */}
              <div className={`w-full h-full flex flex-col items-center gap-6 animate-spring-in ${
                selectedImage 
                  ? 'opacity-100 scale-100' 
                  : 'opacity-0 scale-90 pointer-events-none absolute'
              }`}>
                {selectedImage && (
                  <>
                    <div className="w-full h-64 rounded-2xl overflow-hidden shadow-sm relative group border border-modern-border">
                      <img
                        src={selectedImage}
                        alt="Meal Preview"
                        className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500 ease-out"
                      />
                      <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenCamera();
                          }}
                          className="bg-white text-modern-text px-4 py-2.5 rounded-xl text-xs font-bold hover:bg-modern-indigo hover:text-white transition-all duration-200 shadow-md flex items-center gap-2 active:scale-95 btn-hover-effect"
                        >
                          <Camera className="w-4 h-4 text-modern-indigo" /> Retake Photo
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedImage(null);
                            setAnalysisResult(null);
                          }}
                          className="bg-white text-modern-rose px-4 py-2.5 rounded-xl text-xs font-bold hover:bg-modern-rose hover:text-white transition-all duration-200 shadow-md flex items-center gap-2 active:scale-95 btn-hover-effect"
                        >
                          <Trash2 className="w-4 h-4 text-modern-rose" /> Remove
                        </button>
                      </div>
                    </div>

                    {!analysisResult && !isAnalyzing && (
                      <div className="w-full flex flex-col gap-3">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleAnalyze();
                          }}
                          className="w-full bg-modern-indigo text-white font-sans uppercase tracking-wider py-4 rounded-2xl text-xs font-bold shadow-md shadow-modern-indigo/10 flex items-center justify-center gap-3 active:scale-[0.98] transition-all duration-150 btn-hover-effect cursor-pointer"
                        >
                          <Sparkles className="w-4 h-4 text-white" /> Analyze Nutritional Value
                        </button>
                        
                        {/* Explicit visual mobile actions since hover is desktop only */}
                        <div className="grid grid-cols-2 gap-3 md:hidden">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleOpenCamera();
                            }}
                            className="bg-slate-50 text-modern-text border border-modern-border py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 active:scale-95 btn-hover-effect"
                          >
                            <Camera className="w-3.5 h-3.5" /> Retake
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedImage(null);
                              setAnalysisResult(null);
                            }}
                            className="bg-slate-50 text-modern-rose border border-modern-border py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 active:scale-95 btn-hover-effect"
                          >
                            <Trash2 className="w-3.5 h-3.5" /> Remove
                          </button>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>

            </div>

            {/* Analysis Loading Overlay */}
            {isAnalyzing && (
              <div className="absolute inset-0 bg-white/95 backdrop-blur-sm flex flex-col items-center justify-center gap-4 transition-all duration-300 z-10">
                <Loader2 className="w-10 h-10 text-modern-indigo animate-spin stroke-[2]" />
                <div className="text-center">
                  <p className="text-modern-text font-bold text-base">Analyzing Nutritional Values...</p>
                  <p className="text-modern-mute text-xs mt-1 font-medium tracking-wider">Using computer vision detection</p>
                </div>
                <div className="w-36 h-1.5 bg-slate-100 rounded-full overflow-hidden mt-2 border border-modern-border">
                  <div className="h-full bg-modern-indigo animate-[loading_2s_infinite]" style={{ width: '80%' }}></div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right: Analysis Result Card */}
        <div className="flex flex-col justify-start">
          {analysisResult ? (
            <div className="card-modern p-8 flex flex-col gap-8 animate-slideUp border border-modern-border">
              {/* Card Header & Save Button */}
              <div className="flex justify-between items-start gap-4">
                <div>
                  <span className="text-[10px] tracking-wider font-extrabold text-modern-indigo uppercase bg-modern-indigo-light px-2.5 py-1 rounded-md">AI Estimation</span>
                  <h3 className="text-2xl font-bold text-modern-text mt-3 leading-snug">
                    {analysisResult.mealName}
                  </h3>
                </div>

                <button
                  disabled={analysisResult.saved}
                  onClick={handleSaveToHistory}
                  className={`p-3.5 rounded-xl flex items-center justify-center transition-all duration-200 focus:outline-none cursor-pointer active:scale-90 ${
                    analysisResult.saved
                      ? 'bg-modern-emerald-light text-modern-emerald border border-modern-emerald/20'
                      : 'bg-modern-indigo text-white hover:bg-modern-indigo-hover shadow-md shadow-modern-indigo/10'
                  }`}
                  title={analysisResult.saved ? "Saved to Journal" : "Save to Journal"}
                >
                  {analysisResult.saved ? <Check className="w-5 h-5 stroke-[2.5]" /> : <Plus className="w-5 h-5 stroke-[2.5]" />}
                </button>
              </div>

              {/* Core Numeric Indicators (Calorie Circle & Chart) */}
              <div className="flex flex-col sm:flex-row items-center justify-around gap-8 my-2">
                {/* Calories Indigo-Rimmed Circle */}
                <div className="relative w-40 h-40 rounded-full border-4 border-modern-indigo-light flex flex-col items-center justify-center shadow-inner bg-slate-50/50">
                  <span className="text-[10px] tracking-wider font-bold text-modern-mute uppercase">Calories</span>
                  <span className="text-4xl font-extrabold text-modern-text my-0.5">
                    {analysisResult.calories}
                  </span>
                  <span className="text-[10px] font-semibold text-modern-indigo tracking-wide">kcal / plate</span>
                </div>

                {/* Doughnut Chart */}
                <div className="w-36 h-36 relative flex items-center justify-center">
                  <Doughnut data={chartData} options={chartOptions} />
                  <div className="absolute flex flex-col items-center">
                    <span className="text-[9px] tracking-wider text-modern-mute font-bold uppercase">Macros</span>
                    <span className="text-sm font-bold text-modern-text">Balanced</span>
                  </div>
                </div>
              </div>

              {/* Detailed Nutrition Breakdown */}
              <div className="grid grid-cols-3 gap-4 border-t border-b border-modern-border py-6">
                {Object.entries(analysisResult.macros).map(([key, macro]) => (
                  <div key={key} className="text-center flex flex-col items-center gap-1">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: macro.color }} />
                      <span className="text-xs text-modern-mute font-semibold tracking-wide">{macro.label}</span>
                    </div>
                    <span className="text-lg font-bold text-modern-text">{macro.value}g</span>
                    <span className="text-[10px] text-modern-mute font-medium tracking-wider">{macro.percentage}% cals</span>
                  </div>
                ))}
              </div>

              {/* Meal Component Tags */}
              <div>
                <h4 className="text-xs font-bold text-modern-text uppercase tracking-wider mb-3">Detected Ingredients</h4>
                <div className="flex flex-wrap gap-2">
                  {analysisResult.ingredients.map((ingredient, i) => (
                    <span
                      key={i}
                      className="bg-slate-50 text-modern-mute text-xs px-3.5 py-1.5 rounded-xl font-medium border border-modern-border tracking-wide"
                    >
                      {ingredient}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            // Empty State Result Panel
            <div className="card-modern p-10 flex flex-col items-center justify-center min-h-[450px] text-center gap-4 border border-modern-border">
              <div className={`w-12 h-12 rounded-full bg-modern-indigo-light flex items-center justify-center border border-modern-indigo/10 mb-2 transition-all duration-300 ${
                selectedImage ? 'animate-pulse-glow border-modern-indigo/30 shadow-[0_0_0_0_rgba(79,70,229,0.3)]' : ''
              }`}>
                <ArrowRight className="w-5 h-5 text-modern-indigo stroke-[2.5]" />
              </div>
              <div>
                <p className="text-modern-text font-bold text-lg">Awaiting Analysis</p>
                <p className="text-modern-mute text-sm font-medium tracking-wide max-w-xs mt-2 leading-relaxed">
                  Provide a meal photograph on the left to reveal dynamic nutritional estimations and macronutrient charts.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Interactive, Modern Camera Modal Overlay */}
      {isCameraOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md flex items-center justify-center z-[100] animate-fadeIn p-4">
          <div className="bg-white rounded-3xl p-6 shadow-xl max-w-md w-full border border-modern-border flex flex-col gap-5 relative animate-slideUp">
            {/* Modal Header */}
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-bold text-modern-text">Take Meal Photo</h3>
              <button
                onClick={handleCloseCamera}
                className="text-modern-mute hover:text-modern-text p-1.5 rounded-xl hover:bg-slate-100 transition-all duration-200 focus:outline-none cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Video Viewport Stream */}
            <div className="aspect-square w-full rounded-2xl overflow-hidden bg-slate-950 relative border border-slate-100 flex items-center justify-center">
              {cameraError ? (
                <div className="p-6 text-center flex flex-col items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-modern-rose-light flex items-center justify-center text-modern-rose mb-1">
                    <ShieldAlert className="w-6 h-6 stroke-[2.5]" />
                  </div>
                  <p className="text-sm font-bold text-modern-text">Camera Access Failed</p>
                  <p className="text-xs text-modern-mute max-w-xs leading-relaxed">
                    {cameraError}
                  </p>
                  <button
                    onClick={handleOpenCamera}
                    className="mt-2 bg-modern-indigo-light text-modern-indigo px-4 py-2 rounded-xl text-xs font-bold hover:bg-modern-indigo hover:text-white transition-all duration-200 btn-hover-effect"
                  >
                    Retry Connection
                  </button>
                </div>
              ) : (
                <>
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover scale-x-[-1]"
                  />
                  {!streamActive && (
                    <div className="absolute inset-0 bg-slate-950 flex flex-col items-center justify-center gap-3 text-white">
                      <Loader2 className="w-8 h-8 animate-spin text-modern-indigo stroke-[2.5]" />
                      <p className="text-xs text-slate-400">Initializing stream...</p>
                    </div>
                  )}
                </>
              )}

              {/* Camera Flash Animation Overlay */}
              <div 
                className={`absolute inset-0 bg-white transition-opacity z-20 pointer-events-none duration-150 ${
                  showFlash ? 'opacity-100' : 'opacity-0'
                }`}
              />
            </div>

            {/* Shutter Capture Bar */}
            {!cameraError && streamActive && (
              <div className="flex items-center justify-between px-6 pt-2">
                <button
                  type="button"
                  onClick={handleCloseCamera}
                  className="text-xs font-bold text-modern-mute hover:text-modern-text transition-colors duration-200 cursor-pointer active:scale-95"
                >
                  Cancel
                </button>

                <button
                  type="button"
                  onClick={handleCapturePhoto}
                  className="w-16 h-16 rounded-full border-4 border-slate-100 flex items-center justify-center bg-white shadow-md hover:scale-105 active:scale-95 transition-all duration-200 group cursor-pointer focus:outline-none"
                  title="Capture Snap"
                >
                  <div className="w-11 h-11 rounded-full bg-modern-indigo group-hover:bg-modern-indigo-hover transition-all duration-250 flex items-center justify-center shadow-inner">
                    <div className="w-3.5 h-3.5 rounded-full bg-white/50 group-hover:scale-125 transition-transform duration-200" />
                  </div>
                </button>

                <div className="w-10 h-10" /> {/* Balanced layout spacer */}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
